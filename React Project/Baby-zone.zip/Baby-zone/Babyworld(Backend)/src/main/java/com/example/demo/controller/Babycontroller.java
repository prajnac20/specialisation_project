package com.example.demo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Productmodel;
import com.example.demo.model.Register;
import com.example.demo.model.User;
import com.example.demo.service.Babyservice;
import com.example.demo.service.Productservice;


@RestController
@CrossOrigin(origins = {"http://localhost:3000"})
public class Babycontroller {
	
	@Autowired
	Babyservice service;
	@Autowired
	Productservice service1;
	
	@PostMapping(value="/save")
	public Register print(@RequestBody Register register) throws Exception
	{
		String tempemail=register.getEmail();
		if(tempemail!= null && "".equals(tempemail))
		{
			Register obj=service.fetchuserbyemail(tempemail);
		   if(obj !=null)
		   {
			   throw new Exception("User is "+tempemail+" already exits");
		   }
		}
		Register obj=null;
		obj=service.store(register);
		return obj;
		
	}
	
	
	@GetMapping("/user/{id}")
	public User getcurruser(@PathVariable("id") int id)
	{
		User user;
		user=service.getcurrentuser(id);
		return user;
		
	}
	
	
	@PostMapping("/savepro")
	public Productmodel saveproduct(@RequestBody Productmodel pm) {
		
		
		pm=service1.getproducts(pm);
		return pm;
		
	}
	@GetMapping("/getpro")
	public List<Productmodel> getproducts() {
		List <Productmodel> list=service1.getallproducts();
		return list;
	}
	@GetMapping("/getpro/{id}")
	public Productmodel getproductbyid(@PathVariable("id") int id) {
		Productmodel producmodel=service1.getprobyid(id);
		return producmodel;
		
		
	}
	

}
