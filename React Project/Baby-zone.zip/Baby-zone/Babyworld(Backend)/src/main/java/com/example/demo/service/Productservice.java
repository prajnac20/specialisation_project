package com.example.demo.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Productmodel;
import com.example.demo.repository.Productrepository;
@Service
public class Productservice {
	@Autowired
	Productrepository repo;

	public Productmodel getproducts(Productmodel pm) {
		
		return repo.save(pm);
	}

	public List<Productmodel> getallproducts() {
	      List<Productmodel> list = repo.findAll();
		return list;
	}

	public Productmodel getprobyid(int id) {
	
		Productmodel pc;
		pc=repo.findById(id).get();
		return pc;
	}

	public Productmodel updateproduct(Productmodel pm) {
		
		return repo.save(pm);
	}

	public Productmodel deletebyid(int id) {
		
		repo.deleteById(id);
		return null;
		 
	}

}
