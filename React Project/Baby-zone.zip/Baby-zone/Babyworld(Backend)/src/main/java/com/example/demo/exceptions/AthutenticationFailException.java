package com.example.demo.exceptions;

public class AthutenticationFailException extends IllegalArgumentException{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public AthutenticationFailException(String msg) {
	super(msg);
}

}
