package com.example.demo.controller;

import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.user.ResponseDto;
import com.example.demo.dto.user.SigninDto;
import com.example.demo.dto.user.SigninResponseDto;
import com.example.demo.dto.user.SignupDto;
import com.example.demo.service.UserService;

@RequestMapping
@RestController
@CrossOrigin(origins = {"http://localhost:3000"})
public class UserContoller {

	
	@Autowired
	UserService userService;
	
	@PostMapping("/signup")
	public ResponseDto signup(@RequestBody SignupDto signupDto) throws NoSuchAlgorithmException {
		
		return userService.signup(signupDto);
	}
	@PostMapping("/signin")
	public SigninResponseDto signin(@RequestBody SigninDto sigindto) {
		return userService.signIn(sigindto);
		
	}
	
}
