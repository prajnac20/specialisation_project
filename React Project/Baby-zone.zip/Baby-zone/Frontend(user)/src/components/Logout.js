import React, { Component } from 'react';
import { useDispatch} from 'react-redux';
import {handleprofile} from '../redux/reducers';
class Logout extends Component {
  constructor(props) {
    super(props);

    this.state={
    

    }
  }
  state = {  }
  
  handlelogout=()=>{
    localStorage.clear();
    window.location.href='/login';
  }

    
  render() { 

    return ( 
      <div>

      <button className="btn btn-dark btn-lg btn-block" height="50px" type="button" onClick={ this.handlelogout} >Logout</button>
      </div>
     );
  }
}
 
export default Logout;



