import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-goldloan',
  templateUrl: './goldloan.component.html',
  styleUrls: ['./goldloan.component.css']
})
export class GoldloanComponent implements OnInit {
  amount2: number=0;
  constructor() { }

  ngOnInit(): void {
  }
  demo2(val1:number,val2:number){

    this.amount2=(val1*val2*0.08)/100;
    }
}
