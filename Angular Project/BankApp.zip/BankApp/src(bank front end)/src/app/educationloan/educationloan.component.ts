import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-educationloan',
  templateUrl: './educationloan.component.html',
  styleUrls: ['./educationloan.component.css']
})
export class EducationloanComponent implements OnInit {
  amount1: number=0;
  constructor() { }

  ngOnInit(): void {
  }
  demo1(val1:number,val2:number){

    this.amount1=(val1*val2*0.06)/100;
    }
}
