import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private user:UserService, private router: Router) { }
us:User=new User();
  ngOnInit(): void {
  }
  saveuser(obj:any){
 this.us.name=obj.name;
 this.us.emailid=obj.emailid;
 this.us.password=obj.password;
 this.us.confirm_password=obj.confirm_password;
 this.us.mobilenumber=obj.mobilenumber;
 if(this.us !==null){
   this.user.save(this.us).subscribe((res)=>{
     console.log(res);
     this.router.navigate(['/about'])
   })
  
 }
  
   
  }


}
